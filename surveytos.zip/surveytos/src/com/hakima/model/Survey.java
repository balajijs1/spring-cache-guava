package com.hakima.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class Survey implements Serializable {

	private String code;
	private String name;
	private boolean showMenu;
	private boolean showProgress;
	private boolean allowPrevious;
	private final List<AbstractSurveySection> sections = new ArrayList<>();

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isShowMenu() {
		return showMenu;
	}

	public void setShowMenu(boolean showMenu) {
		this.showMenu = showMenu;
	}

	public boolean isShowProgress() {
		return showProgress;
	}

	public void setShowProgress(boolean showProgress) {
		this.showProgress = showProgress;
	}

	public boolean isAllowPrevious() {
		return allowPrevious;
	}

	public void setAllowPrevious(boolean allowPrevious) {
		this.allowPrevious = allowPrevious;
	}

	public List<AbstractSurveySection> getSections() {
		return sections;
	}

	public void setSections(List<AbstractSurveySection> sections) {
		this.sections.clear();
		this.sections.addAll(sections);
	}

	public void addSection(AbstractSurveySection section) {
		this.sections.add(section);
	}

	public AbstractSurveySection getSection(int sectionId) {
		return sections.get(sectionId);
	}

}