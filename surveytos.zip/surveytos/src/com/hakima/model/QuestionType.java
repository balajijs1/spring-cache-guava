package com.hakima.model;

/**
 * @author irbouho
 * @since 1.0.0
 */
public enum QuestionType {

	CHECKBOX,
	COMBOBOX,
	DATE,
	INT,
	LISTBOX,
	MATRIX,
	MATRIX_ROW,
	RADIO,
	TEXT,
	TEXTAREA

}