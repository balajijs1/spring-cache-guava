package com.hakima.model;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class DateQuestion extends AbstractQuestion {

	private String format = "YYYY-MM-dd";

	public DateQuestion() {
		super(QuestionType.DATE);
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public static DateQuestion newDate(String code, String name,
										boolean required,
										String hint) {
		DateQuestion q = new DateQuestion();
		q.setCode(code);
		q.setName(name);
		q.setRequired(required);
		q.setHint(hint);
		return q;
	}

}