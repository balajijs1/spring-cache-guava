package com.hakima.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static java.util.Arrays.asList;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class MatrixQuestion extends AbstractMultiValueQuestion {

	private final QuestionType subType;

	private final List<MatrixRow> rows = new ArrayList<>();

	public MatrixQuestion(QuestionType subType) {
		super(QuestionType.MATRIX);
		this.subType = subType;
	}

	public QuestionType getSubType() {
		return subType;
	}

	public List<MatrixRow> getRows() {
		return this.rows;
	}

	public void setRows(Collection<MatrixRow> rows) {
		this.rows.clear();
		this.rows.addAll(rows);
	}

	public static MatrixQuestion newRadioMatrix(String code, String name, boolean required,
												String hint,
												Collection<MatrixRow> rows,
												Option... options) {
		MatrixQuestion m = new MatrixQuestion(QuestionType.RADIO);
		m.setCode(code);
		m.setName(name);
		m.setRequired(required);
		m.setHint(hint);
		m.setRows(rows);
		m.setOptions(asList(options));
		return m;
	}

}