package com.hakima.model;

/**
 * @author irbouho
 * @since 1.0.0
 */
public abstract class AbstractSurveySection extends AbstractConditionalElement {

	private final SectionType type;

	private String code;
	private String name;
	private String shortName;
	private String hint;
	private String comments;

	AbstractSurveySection(SectionType sectionType) {
		this.type = sectionType;
	}

	public SectionType getType() {
		return type;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getHint() {
		return hint;
	}

	public void setHint(String hint) {
		this.hint = hint;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

}