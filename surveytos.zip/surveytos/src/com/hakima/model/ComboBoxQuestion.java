package com.hakima.model;

import static java.util.Arrays.asList;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class ComboBoxQuestion extends AbstractMultiValueQuestion {

	public ComboBoxQuestion() {
		super(QuestionType.COMBOBOX);
	}

	public static ComboBoxQuestion newComboBox(String code, String name, boolean required,
											   String width,
											   String hint,
											   Option... options) {
		ComboBoxQuestion q = new ComboBoxQuestion();
		q.setCode(code);
		q.setName(name);
		q.setRequired(required);
		q.setWidth(width);
		q.setHint(hint);
		q.setOptions(asList(options));
		return q;
	}

}