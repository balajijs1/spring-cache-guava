package com.hakima.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class Questionnaire implements Serializable {

	private int sectionId;
	private ActionType action;
	private final Map<Integer, Boolean> enabledSections = new HashMap<>();

	private Map<String, Object> answers = new HashMap<>();

	public int getSectionId() {
		return sectionId;
	}

	public void setSectionId(int sectionId) {
		this.sectionId = sectionId;
	}

	public ActionType getAction() {
		return action;
	}

	public void setAction(ActionType action) {
		this.action = action;
	}

	public Map<String, Object> getAnswers() {
		return answers;
	}

	public void setAnswers(Map<String, Object> answers) {
		this.answers = answers;
	}

	public Map<Integer, Boolean> getEnabledSections() {
		return enabledSections;
	}

	public void setEnabledSections(Map<Integer, Boolean> enabledSections) {
		this.enabledSections.clear();
		this.enabledSections.putAll(enabledSections);
	}

	public boolean isSectionEnabled(Integer sectionId) {
		return this.enabledSections.containsKey(sectionId);
	}

	public void enableSection(Integer sectionId) {
		this.sectionId = sectionId;
		this.enabledSections.put(sectionId, Boolean.TRUE);
	}

}