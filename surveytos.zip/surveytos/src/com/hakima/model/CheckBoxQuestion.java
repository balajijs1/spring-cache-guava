package com.hakima.model;

import static java.util.Arrays.asList;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class CheckBoxQuestion extends AbstractMultiValueQuestion {

	public CheckBoxQuestion() {
		super(QuestionType.CHECKBOX);
	}

	public static CheckBoxQuestion newCheckBox(String code, String name, boolean required,
											   String hint,
											   Option... options) {
		CheckBoxQuestion q = new CheckBoxQuestion();
		q.setCode(code);
		q.setName(name);
		q.setRequired(required);
		q.setHint(hint);
		q.setOptions(asList(options));
		return q;
	}

}