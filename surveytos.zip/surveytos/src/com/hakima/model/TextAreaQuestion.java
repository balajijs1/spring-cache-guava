package com.hakima.model;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class TextAreaQuestion extends TextQuestion {

	private int rows = 5;

	public TextAreaQuestion() {
		super(QuestionType.TEXTAREA);
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	public static TextQuestion newTextArea(String code, String name, boolean required,
										   int rows, String width, int maxLength,
										   String hint) {
		TextAreaQuestion q = new TextAreaQuestion();
		q.setCode(code);
		q.setName(name);
		q.setRequired(required);
		q.setWidth(width);
		q.setRows(rows);
		q.setMaxLength(maxLength);
		q.setHint(hint);
		return q;
	}

}