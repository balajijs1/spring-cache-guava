package com.hakima.web;

import com.hakima.dao.SurveyDao;
import com.hakima.model.Questionnaire;
import com.hakima.model.Survey;
import com.hakima.model.SurveyExecution;
import org.springframework.beans.propertyeditors.CustomCollectionEditor;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * @author irbouho
 * @since 1.0.0
 */
@Controller
@RequestMapping("/survey")
@SessionAttributes("questionnaire")
public class SurveyController {

	private final SurveyDao surveyDao;
	private final SpelExpressionParser parser;

	public SurveyController(SurveyDao surveyDao, SpelExpressionParser parser) {
		this.surveyDao = surveyDao;
		this.parser = parser;
	}

	@ModelAttribute
	public Questionnaire createModel() {
		Questionnaire q = new Questionnaire();
		q.enableSection(0);
		return q;
	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(Integer.class, "answers[age]", new CustomNumberEditor(Integer.class, true));
		binder.registerCustomEditor(Date.class, "answers[birthDate]", new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true));
		binder.registerCustomEditor(Date.class, "answers[hobbies]", new CustomCollectionEditor(List.class, true));
		binder.registerCustomEditor(Date.class, "answers[drinks]", new CustomCollectionEditor(List.class, true));
		binder.registerCustomEditor(Date.class, "answers[food]", new CustomCollectionEditor(List.class, true));
		binder.registerCustomEditor(Date.class, "answers[clothes]", new CustomCollectionEditor(List.class, true));
	}

	@RequestMapping(value = "/{sectionId}", method = RequestMethod.GET)
	public String survey(Model model,
						 @ModelAttribute Questionnaire questionnaire,
						 Errors errors) {

		// calculate sectionId
		computeSectionId(questionnaire);
		questionnaire.enableSection(questionnaire.getSectionId());

		// generate reference data
		referenceData(model, questionnaire);
		return "survey";
	}

	@RequestMapping(method = RequestMethod.POST)
	public String process(Model model,
						  @ModelAttribute @Validated Questionnaire questionnaire,
						  Errors errors) {

		int currentId = questionnaire.getSectionId();
		computeSectionId(questionnaire);
		int sectionId = questionnaire.getSectionId();

		if (currentId == sectionId && !errors.hasErrors()) {
			// compute section
			switch (questionnaire.getAction()) {
				case NEXT:
				case PROCEED:
					if (sectionId < getSurvey().getSections().size() - 1) {
						sectionId++;
					}
					break;

				case PREVIOUS:
					if (sectionId > 0) {
						sectionId--;
					}
					break;

				case SUBMIT:
					System.out.println("We're done here!");
					break;
			}

			questionnaire.enableSection(sectionId);
		}

		referenceData(model, questionnaire);
		return "survey";
	}

	private void computeSectionId(Questionnaire questionnaire) {
		int sectionId = questionnaire.getSectionId();

		if (!questionnaire.isSectionEnabled(sectionId)) {

			// go back to first section
			questionnaire.enableSection(0);
		}
	}

	private void referenceData(Model model, Questionnaire questionnaire) {
		Survey survey = getSurvey();

		model.addAttribute("execution", new SurveyExecution(survey, questionnaire, parser));
	}

	private Survey getSurvey() {
		return surveyDao.getByCode("sample");
	}

}