package com.hakima.model;

/**
 * @author irbouho
 * @since 1.0.0
 */
public abstract class AbstractQuestion extends AbstractConditionalElement {

	private final QuestionType type;

	private String code;
	private String name;
	private String hint;
	private String comments;
	private boolean required;

	AbstractQuestion(QuestionType type) {
		this.type = type;
	}

	public QuestionType getType() {
		return type;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHint() {
		return hint;
	}

	public void setHint(String hint) {
		this.hint = hint;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public boolean isRequired() {
		return required;
	}

	public void setRequired(boolean required) {
		this.required = required;
	}

}