package com.hakima.model;

import org.springframework.expression.Expression;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.util.StringUtils;

import java.io.Serializable;

/**
 * @author irbouho
 * @since 1.0.0
 */
public abstract class AbstractConditionalElement implements Serializable {

	private String condition;

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public boolean evaluate(SpelExpressionParser parser, EvaluationContext context) {
		boolean result = true;
		if (StringUtils.hasText(condition)) {
			// create an expression
			Expression expression = parser.parseExpression(condition);

			// evaluate
			result = expression.getValue(context, Boolean.class);
		}

		return result;
	}

	public static EvaluationContext newContext(Survey survey,
											   AbstractSurveySection section,
											   Questionnaire questionnaire,
											   Object element) {
		return new EvaluationContext(survey, section, questionnaire, element);
	}

	static class EvaluationContext implements Serializable {

		private final Survey survey;
		private final AbstractSurveySection section;
		private final Questionnaire questionnaire;
		private final Object element;

		EvaluationContext(Survey survey,
						  AbstractSurveySection section,
						  Questionnaire questionnaire,
						  Object element) {
			this.survey = survey;
			this.section = section;
			this.questionnaire = questionnaire;
			this.element = element;
		}

		public Survey getSurvey() {
			return survey;
		}

		public AbstractSurveySection getSection() {
			return section;
		}

		public Questionnaire getQuestionnaire() {
			return questionnaire;
		}

		public Object getElement() {
			return element;
		}

	}

}