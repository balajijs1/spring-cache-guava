package com.hakima.config;

import org.springframework.context.annotation.*;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.expression.spel.SpelCompilerMode;
import org.springframework.expression.spel.SpelParserConfiguration;
import org.springframework.expression.spel.standard.SpelExpressionParser;

/**
 * @author irbouho
 * @since 1.0.0
 */
@Configuration
@Import({

})
@PropertySource("classpath:/com/hakima/config/config_${CONFIG_MODE:DEV}.properties")
@ComponentScan(basePackages = {"com.hakima.dao"})
public class AppConfig {

	@Bean
	public static PropertySourcesPlaceholderConfigurer property_placeholder_configurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	@Bean(name = "messageSource")
	public ResourceBundleMessageSource message_source() {
		ResourceBundleMessageSource source = new ResourceBundleMessageSource();
		source.setDefaultEncoding("UTF-8");
		source.setBasename("com.hakima.messages");

		return source;
	}

	@Bean(name = "expressionParser")
	public SpelExpressionParser expression_parser() {
		SpelParserConfiguration config = new SpelParserConfiguration(SpelCompilerMode.MIXED, null);
		return new SpelExpressionParser(config);
	}

}