package com.hakima.model;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class SummarySurveySection extends AbstractSurveySection {

	public SummarySurveySection() {
		super(SectionType.SUMMARY);
	}

}