package com.hakima.model;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class MatrixRow extends AbstractQuestion {

	public MatrixRow() {
		super(QuestionType.MATRIX_ROW);
	}

	protected MatrixRow(QuestionType type) {
		super(type);
	}

	public static MatrixRow newRow(String code, String name, boolean required, String hint) {
		MatrixRow q = new MatrixRow();
		q.setCode(code);
		q.setName(name);
		q.setRequired(required);
		q.setHint(hint);
		return q;
	}

}